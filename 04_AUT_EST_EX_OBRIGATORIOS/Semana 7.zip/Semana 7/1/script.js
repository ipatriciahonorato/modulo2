function Somar(){
    var entrada = Number(document.getElementById("quantidade").value)
    var entrada2 = entrada += 1
    document.getElementById("quantidade").value = String (entrada2)
}

function Subtrair(){
    var entrada = Number(document.getElementById("quantidade").value)
    var entrada3 = entrada -=1
    document.getElementById("quantidade").value = String (entrada3)
}