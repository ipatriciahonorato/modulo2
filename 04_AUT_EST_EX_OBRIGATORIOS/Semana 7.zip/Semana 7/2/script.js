function Trocar(){
    var entrada1 = (document.getElementById("entrada1").value);
    var entrada2 = (document.getElementById("entrada2").value);
    document.getElementById("entrada1").value = entrada2
    document.getElementById("entrada2").value = entrada1
}