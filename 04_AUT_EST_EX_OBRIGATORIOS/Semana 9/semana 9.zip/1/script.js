function total(){
    var numero= (document.getElementById("valor").value)

    if(numero % 2 == 0) {
        alert("O número é par");
    }

    else {
        alert("O número é ímpar");
    }
}